These routes are preconfigured to use with some apps!

Before using them, you'll need to make sure that the output address and ports match the ones on the
app.

For VRCFacetracking 5.0 you will need to configure the output address and port yourself. You can do
that by launching VRCFT, looking for the cogwheel button at the bottom left and setting the receive
port and receive ip address to match the output address and output port in the router configuration.
The send port should be set to 9000.
